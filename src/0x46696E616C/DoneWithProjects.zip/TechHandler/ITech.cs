﻿namespace TechHandler
{
    public interface ITech
    {
    }
}