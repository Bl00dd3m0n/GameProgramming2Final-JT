﻿using _0x46696E616C.WorldManager.ConcreteImplementations.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0x46696E616C.ConcreteImplementations.Resources
{
    public class Wood : IResource
    {
        public float Count { get; set; }
    }
}
