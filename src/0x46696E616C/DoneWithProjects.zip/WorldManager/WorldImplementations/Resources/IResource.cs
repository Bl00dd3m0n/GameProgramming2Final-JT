﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0x46696E616C.WorldManager.ConcreteImplementations.Resources
{
    public interface IResource
    {
        float Count { get; set; }
    }
}
