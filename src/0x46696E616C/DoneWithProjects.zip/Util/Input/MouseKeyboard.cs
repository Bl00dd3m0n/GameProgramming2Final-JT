﻿namespace _0x46696E616C.InputManager
{
    public class MouseKeyboard : InputHandler
    {

    }
}