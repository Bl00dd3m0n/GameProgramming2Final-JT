﻿using System;
using System.Collections.Generic;
using _0x46696E616C.MobHandler.Units;

namespace MobHandler.HostileMobManager
{
    public class WaveDetails
    {
        internal List<IUnit> GetUnits()
        {
            throw new NotImplementedException();
        }
    }
}